
# Libraries

#install.packages("tidyverse")
#install.packages("janitor")
library(tidyverse)
library(readxl)
library(janitor)
 library(ggplot2)
#install.packages("ggpubr")
#install.packages("patchwork")
library(smplot2)
install.packages("DescTools")
library(DescTools)
library("ggpubr")
library(patchwork)
#install.packages("ggfortify")
library(ggfortify)
#install.packages("GGally")
library(GGally)
 #install.packages("summarySE")
 #install.packages('Rmisc', dependencies = TRUE)
 #install.packages("doBy")
 library(doBy)
library(Rmisc)
library(broom)
 library(scales)
 #install.packages("sjmisc")
library(sjmisc)
 #install.packages("kableExtra")
library(kableExtra)
 #install.packages("stringr")         
 library("stringr") 
#library(summarySE)
 library(car)
 #install.packages("emmeans")   
library(emmeans)
library(RColorBrewer)
library(viridis)
library(rstatix)
library(kableExtra)

#install.packages("ggcorrplot")
library(ggcorrplot)
# Colour palletes
colorBlindBlackmodif <- c("#A6CCA3", 
                          "#85D2FF", "#D55E00", "#CC79A7")

colorBlindBlack8  <- c( "#E69F00", "#56B4E9", "#009E73", 
                       "#F0E442", "#0072B2", "#D55E00", "#CC79A7")

cbbPalette <- c("#808080", "#E69F00", "#56B4E9", "#009E73", "yellow4", "#0072B2", "#D55E00", "#CC79A7","#A6CCA3")

cbbPalettem <- c( "#56B4E9", "#E69F00", "#CC79A7","#808080")

# helping funcitons
`%nin%` = Negate(`%in%`)
#install.packages("ggbeeswarm")
library(ggbeeswarm)
# to remove every object
 #rm(list = ls())
 